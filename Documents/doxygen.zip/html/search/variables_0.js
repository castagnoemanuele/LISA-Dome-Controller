var searchData=
[
  ['currentdegrees_0',['currentDegrees',['../struct_encoder.html#ac84a417488490c90c4c48ea020f81f48',1,'Encoder']]]
];
