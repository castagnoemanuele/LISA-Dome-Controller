var searchData=
[
  ['newsector_0',['newSector',['../struct_encoder.html#a475b81ff78e33f3bcacd8cb18aff7c6a',1,'Encoder']]],
  ['numberkeypresses_1',['numberKeyPresses',['../struct_button.html#a70302361a18ea7cdb4d92af0506bda05',1,'Button']]]
];
