var annotated_dup =
[
    [ "Button", "struct_button.html", "struct_button" ],
    [ "DisplayOled", "class_display_oled.html", "class_display_oled" ],
    [ "Encoder", "struct_encoder.html", "struct_encoder" ],
    [ "Telescope", "class_telescope.html", "class_telescope" ]
];