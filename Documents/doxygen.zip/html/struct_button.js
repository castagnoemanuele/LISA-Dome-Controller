var struct_button =
[
    [ "message", "struct_button.html#a631109cef944c62d1eb312496c02822e", null ],
    [ "numberKeyPresses", "struct_button.html#a70302361a18ea7cdb4d92af0506bda05", null ],
    [ "pressed", "struct_button.html#a5e7b737e832d3567e3bb1fa0b5064b76", null ]
];