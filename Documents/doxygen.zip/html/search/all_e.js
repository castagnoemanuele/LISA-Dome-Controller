var searchData=
[
  ['telescope_0',['Telescope',['../class_telescope.html',1,'']]],
  ['telescope_2ecpp_1',['telescope.cpp',['../telescope_8cpp.html',1,'']]],
  ['telescope_2eh_2',['telescope.h',['../telescope_8h.html',1,'']]]
];
