var searchData=
[
  ['savedata_0',['saveData',['../encoder_8cpp.html#a69b92e165de7d3ce033d5730f7b771ea',1,'saveData(int data, const char *address, Preferences &amp;preferences):&#160;encoder.cpp'],['../encoder_8h.html#a69b92e165de7d3ce033d5730f7b771ea',1,'saveData(int data, const char *address, Preferences &amp;preferences):&#160;encoder.cpp']]]
];
