var struct_encoder =
[
    [ "currentDegrees", "struct_encoder.html#ac84a417488490c90c4c48ea020f81f48", null ],
    [ "direction", "struct_encoder.html#a6a0ac5efc67d338570be695a611ce654", null ],
    [ "fullRotation", "struct_encoder.html#a37efa317b97fdd2ec3596427acb0db86", null ],
    [ "hasChanged", "struct_encoder.html#a64414d71c5cd55d353360959379b1315", null ],
    [ "newSector", "struct_encoder.html#a475b81ff78e33f3bcacd8cb18aff7c6a", null ],
    [ "oldSector", "struct_encoder.html#ad786d8927224ce906bced40984f99bbb", null ]
];