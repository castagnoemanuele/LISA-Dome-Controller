var class_telescope =
[
    [ "checkTelescopePosition", "class_telescope.html#a656cf6636d6e2117bc493622bd6f0583", null ],
    [ "convertRA", "class_telescope.html#a1f67422ddab71428a8007aebdc9e71ab", null ]
];