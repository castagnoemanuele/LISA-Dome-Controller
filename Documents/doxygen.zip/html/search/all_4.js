var searchData=
[
  ['fullrotation_0',['fullRotation',['../struct_encoder.html#a37efa317b97fdd2ec3596427acb0db86',1,'Encoder']]]
];
