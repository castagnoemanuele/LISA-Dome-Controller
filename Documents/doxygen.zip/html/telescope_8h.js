var telescope_8h =
[
    [ "Telescope", "class_telescope.html", "class_telescope" ]
];