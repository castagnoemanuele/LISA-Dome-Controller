var searchData=
[
  ['encoder_0',['Encoder',['../struct_encoder.html',1,'']]]
];
