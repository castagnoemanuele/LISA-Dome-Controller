var searchData=
[
  ['direction_0',['direction',['../struct_encoder.html#a6a0ac5efc67d338570be695a611ce654',1,'Encoder']]]
];
