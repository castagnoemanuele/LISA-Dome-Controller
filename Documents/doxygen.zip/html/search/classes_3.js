var searchData=
[
  ['telescope_0',['Telescope',['../class_telescope.html',1,'']]]
];
