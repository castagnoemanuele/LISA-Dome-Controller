var searchData=
[
  ['checkencoder_0',['checkEncoder',['../encoder_8cpp.html#a139de19c980f779e48e01d1f8fba4263',1,'checkEncoder(Encoder &amp;encoder1):&#160;encoder.cpp'],['../encoder_8h.html#a139de19c980f779e48e01d1f8fba4263',1,'checkEncoder(Encoder &amp;encoder1):&#160;encoder.cpp']]],
  ['checktelescopeposition_1',['checkTelescopePosition',['../class_telescope.html#a656cf6636d6e2117bc493622bd6f0583',1,'Telescope']]],
  ['convertra_2',['convertRA',['../class_telescope.html#a1f67422ddab71428a8007aebdc9e71ab',1,'Telescope']]],
  ['converttickstodegrees_3',['convertTicksToDegrees',['../encoder_8cpp.html#a112a738a79a560eacdc5b40f58245cc2',1,'convertTicksToDegrees(int ticks, Encoder &amp;encoder1):&#160;encoder.cpp'],['../encoder_8h.html#a112a738a79a560eacdc5b40f58245cc2',1,'convertTicksToDegrees(int ticks, Encoder &amp;encoder1):&#160;encoder.cpp']]],
  ['countticksfullrotation_4',['countTicksFullRotation',['../encoder_8cpp.html#a6fb249c32b91843aad4ba18b0fa57eee',1,'countTicksFullRotation(Encoder &amp;encoder1, Button &amp;resetButton, Button &amp;limitSwitch, Preferences &amp;preferences):&#160;encoder.cpp'],['../encoder_8h.html#a38add31e961db4ece7f2d98d6c33156c',1,'countTicksFullRotation(Encoder &amp;encoder1, Button &amp;buttonReset, Button &amp;limitSwitch, Preferences &amp;preferences):&#160;encoder.cpp']]]
];
