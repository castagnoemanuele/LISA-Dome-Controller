var encoder_8cpp =
[
    [ "checkEncoder", "encoder_8cpp.html#a139de19c980f779e48e01d1f8fba4263", null ],
    [ "convertTicksToDegrees", "encoder_8cpp.html#a112a738a79a560eacdc5b40f58245cc2", null ],
    [ "countTicksFullRotation", "encoder_8cpp.html#a6fb249c32b91843aad4ba18b0fa57eee", null ],
    [ "resetPosition", "encoder_8cpp.html#a18be2eefa5e60c230e95d15dbdc79f2a", null ],
    [ "saveData", "encoder_8cpp.html#a69b92e165de7d3ce033d5730f7b771ea", null ],
    [ "updatePosition", "encoder_8cpp.html#aea3da456e252aa2089661fd06157ec2f", null ]
];