var searchData=
[
  ['telescope_2ecpp_0',['telescope.cpp',['../telescope_8cpp.html',1,'']]],
  ['telescope_2eh_1',['telescope.h',['../telescope_8h.html',1,'']]]
];
