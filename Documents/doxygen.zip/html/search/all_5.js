var searchData=
[
  ['haschanged_0',['hasChanged',['../struct_encoder.html#a64414d71c5cd55d353360959379b1315',1,'Encoder']]]
];
