var searchData=
[
  ['oldsector_0',['oldSector',['../struct_encoder.html#ad786d8927224ce906bced40984f99bbb',1,'Encoder']]]
];
