var encoder_8h =
[
    [ "Encoder", "struct_encoder.html", "struct_encoder" ],
    [ "checkEncoder", "encoder_8h.html#a139de19c980f779e48e01d1f8fba4263", null ],
    [ "convertTicksToDegrees", "encoder_8h.html#a112a738a79a560eacdc5b40f58245cc2", null ],
    [ "countTicksFullRotation", "encoder_8h.html#a38add31e961db4ece7f2d98d6c33156c", null ],
    [ "resetPosition", "encoder_8h.html#ac168af46c2980b991b3e14269c483d66", null ],
    [ "saveData", "encoder_8h.html#a69b92e165de7d3ce033d5730f7b771ea", null ],
    [ "updatePosition", "encoder_8h.html#aea3da456e252aa2089661fd06157ec2f", null ]
];